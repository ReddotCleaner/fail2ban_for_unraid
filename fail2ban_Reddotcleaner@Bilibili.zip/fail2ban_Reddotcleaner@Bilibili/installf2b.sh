python3 ./setup.py install
sleep 5
cp ./jail.local /etc/fail2ban/
fail2ban-client start
